/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practicagit;

/**
 *
 * @author DAW127
 */
public class PracticaGIT {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
