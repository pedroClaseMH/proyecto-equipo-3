/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Calculadora;

import java.util.Scanner;

/**
 *
 * @author DAW113
 */
public class Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
         Scanner sc = new Scanner(System.in);
        
        System.out.println("=== CALCULADORA ===");
        
        System.out.print("Introduce el primer número: ");
        double num1 = sc.nextDouble();
        
        System.out.print("Introduce el segundo número: ");
        double num2 = sc.nextDouble();
        
        System.out.println("Elige una operación:");
        System.out.println("1 - Sumar");
        System.out.println("2 - Restar");
        System.out.println("3 - Multiplicar");
        System.out.println("4 - Dividir");
        
        int opcion = sc.nextInt();
        
         double resultado = 0;
        
        switch (opcion) {
            case 1:
                resultado = num1 + num2;
                System.out.println("Resultado: " + resultado);
                break;
                
            case 2:
                resultado = num1 - num2;
                System.out.println("Resultado: " + resultado);
                break;
                
            case 3:
                resultado = num1 * num2;
                System.out.println("Resultado: " + resultado);
                break;
                
            case 4:
                 if (num2 != 0) {
                    resultado = num1 / num2;
                    System.out.println("Resultado: " + resultado);
                } else {
                    System.out.println("Error: No se puede dividir entre 0.");
                }
                break;
                
            default:
                System.out.println("Opción no válida.");
        }
        
        sc.close();
    
    }
    
}
